class Config:
    SIZE = 9
    ROW_SIZE = 9
    COL_SIZE = 9
    BOX_SIZE = 3
